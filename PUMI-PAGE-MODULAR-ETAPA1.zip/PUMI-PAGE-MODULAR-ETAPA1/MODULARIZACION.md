# PUMI-PAGE modular — Etapa 1 segura

Esta versión fue generada desde `PUMI-PAGE-main (10)`.

## Objetivo
Separar físicamente el archivo monolítico sin cambiar la lógica funcional ni las rutas de la API.

## Conexión
- GitHub Pages sigue cargando `index.html`.
- `config/config.js` conserva la misma URL de Render.
- `services/api-service.js` no fue modificado.
- Render/PUMI-API no requiere cambios para esta etapa.

## Módulos
- `js/core/core.js`: sesión, carga de datos, permisos y utilidades de dominio base.
- `js/modules/dashboard-shell.js`: selector principal de panel por perfil.
- `js/modules/visor.js`: panel y filtros del Visor Nacional.
- `js/modules/dashboard-common.js`: paneles comunes, VIF y consolidaciones.
- `js/modules/delegacion.js`: registro, edición, detalle y Mis registros.
- `js/modules/revision.js`: revisión regional/nacional y notificaciones.
- `js/modules/mapas.js`: mapas, puntos, geometrías y leyendas.
- `js/modules/ui.js`: mejoras visuales inyectadas.
- `js/modules/informes.js`: informes PDF y controles asociados.
- `js/modules/utils.js`: normalización, números y territorios.

## Respaldo
`js/legacy/app.monolith.backup.js` contiene el `app.js` original completo y no se carga.

## Regla para próximas correcciones
No volver a reemplazar todos los módulos. Modificar únicamente el archivo responsable del área.
